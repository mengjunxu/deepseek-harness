# 执行计划

## 阶段 1：{{phase}}

- [ ] {{first_verifiable_item}}
- [ ] {{next_verifiable_item}}

状态：NOT_STARTED

## 验证计划与结果

- 命令或人工动作：{{verification}}
- 预期：{{expected_outcome}}
- 实际：NOT_RUN
- 对应代码或文件快照：尚未验证。
- 未执行原因：尚未开始。

## 后续路线

{{existing_roadmap_link_or_scoped_V1_V2_backlog}}
