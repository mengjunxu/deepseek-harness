# 共享工程知识索引

这里只保存反复有用且可核实的事实与资料链接。任务进度放在任务记录，决策理由由正式决策记录拥有。

- 项目规则：{{project_rules}}
- 共享工作流：{{workflow_path}}
- 架构与已确认决策：{{architecture_and_decision_sources}}
- 已验证的开发与检查入口：{{verified_development_sources_or_none}}

新知识应附可核对来源；临时推测和当前环境阻塞留在任务日志，不升格为长期规则。
