# 架构事实索引

## 当前可确认的事实

- 项目用途与技术栈：{{verified_project_facts}}
- 适用的 Agent 入口：{{agent_entry_files}}
- 产品架构文档：{{architecture_sources_or_none}}
- 已确认决策记录及其生命周期规则：{{decision_sources_or_none}}
- 已有 Task、Session、Workflow、Memory、Workspace 的所有者：{{verified_existing_owners_or_unknown}}

## 阅读与变更约束

相关工作先读取实际拥有该事实的文档或实现；此文件只做索引，不复制决策全文。提案和历史记录不能因被链接就成为当前已确认决策。未知项保持未知，由实际证据补充。
