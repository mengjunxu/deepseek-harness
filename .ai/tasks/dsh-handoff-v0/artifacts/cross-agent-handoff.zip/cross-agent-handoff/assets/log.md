# 任务日志

## {{timestamp}} — {{event}}

- 执行者：{{agent}}
- 状态转换与原因：{{transition_and_reason}}
- 关键动作：{{action}}
- 证据与结果：{{evidence_and_observation}}
- 后续影响：{{effect_on_next_work}}
