---
schema_version: 1
task_id: "{{task_id}}"
state: PLANNED
previous_agent: null
next_agent: null
branch: null
base_commit: null
tested_code_commit: null
updated_at: "{{updated_at}}"
---

# 交接 Checkpoint

## 当前状态

{{current_status}}

## 已完成与未完成

- 已完成：{{verified_completed_items_or_none}}
- 未完成：{{remaining_items}}

## 工作区与版本

- 实际目录：{{workspace}}
- 分支与基线版本：{{actual_version_or_no_version_system}}
- 本任务修改：{{task_owned_changes_or_none}}
- 原有无关修改与未跟踪文件：{{existing_changes_or_none}}
- 保存、提交、推送及跨设备同步：{{actual_save_and_sync_state}}
- 旧写入者停止证据：{{writer_stop_evidence_or_unconfirmed}}

## 验证证据

- 命令或人工动作：{{verification_or_none}}
- 结果：NOT_RUN
- 对应版本或文件快照：{{tested_snapshot_or_none}}
- 未执行项目与原因：{{unrun_checks}}

## 约束与风险

{{confirmed_decision_links_known_issues_and_limits}}

## 下一步

1. {{first_incomplete_action}}
2. {{next_action}}

## 用户决策

{{required_decisions_or_none}}
