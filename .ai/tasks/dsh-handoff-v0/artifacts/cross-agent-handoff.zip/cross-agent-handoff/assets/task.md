---
schema_version: 1
task_id: "{{task_id}}"
title: "{{title}}"
status: PLANNED
created_at: "{{created_at}}"
updated_at: "{{updated_at}}"
---

# 任务目标

{{goal}}

## 背景

{{background}}

## 范围

- 包含：{{in_scope}}
- 不包含：{{out_of_scope}}

## 验收

- [ ] {{observable_acceptance}}
- [ ] 相关检查和未验证项目有真实记录。
- [ ] 相关文档已更新，已确认决策得到遵守。

## 依赖与约束

{{dependencies_and_confirmed_decisions}}

## 用户决策

{{required_decisions_or_none}}
