---
name: cross-agent-handoff
description: "Set up a portable V0 handoff workflow for Codex, Codely, or other coding agents in a new folder or existing repository, with shared instructions, task checkpoints, and bidirectional validation. Use when establishing or adapting cross-agent collaboration; supports later handoff and resume requests using those records."
---

# Cross-Agent Handoff

在用户指定的文件夹建立可手动执行的跨 Agent 工作流。默认支持 Codex 与 Codely，也适用于用户指定的其他执行端。交付共享规则、事实索引、任务模板、实际试点记录和验证证据。

## 输入与范围

- 目标目录取用户指定路径；用户明确指当前项目时使用当前目录。确实无法确定目标时只询问路径，先检查可独立确认的信息。
- 用户提供方案时先完整阅读；输出被截断时分段补读。用户没有提供方案时按本 Skill 的 V0 范围落地。
- 用户只要求交接或恢复现有任务时，直接采用目标项目的共享规则和任务记录，不重新初始化目录。
- 默认交付 V0。只有用户要求后才实施 V1/V2；本 Skill 的模板复制不意味着需要开发初始化工具或调度服务。

## 1. 侦察并映射现有结构

写入前检查目录是否存在、是否为空、是否是 Git 工作区、目标路径是否位于更大的父仓库中，以及适用的父级和子级 Agent 指令。

读取现有 Agent 入口、README、贡献规范、架构文档、已确认决策、任务/计划/Checkpoint/Memory，以及已有脚本和验证命令。区分已确认决策、提案和历史记录，保留它们的实际权威来源。

Git 可用时核对分支、HEAD、状态、暂存和未暂存 Diff、未跟踪文件、冲突与远程配置。建立用户原有修改清单。非 Git 文件夹明确记录版本证据不可用；不要把文件夹初始化请求解释为 Git 初始化、提交或创建远程仓库的授权。

用简短进度更新说明映射：哪些已有结构可复用、哪些文件需要新增、哪些入口只需追加引用。随后继续已授权的工作，不把映射汇报变成额外审批步骤。

## 2. 落地共享记录

优先沿用已有的工作流、决策和任务目录。不存在等价结构时使用：

```text
AGENTS.md
CODELY.md                 # 仅在实际执行端适用时使用
.ai/
  WORKFLOW.md
  ARCHITECTURE.md
  MEMORY.md
  templates/{task,plan,handoff,log}.md
  tasks/<task-id>/{task,plan,handoff,log}.md
```

从 [assets/WORKFLOW.md](assets/WORKFLOW.md)、[assets/ARCHITECTURE.md](assets/ARCHITECTURE.md)、[assets/MEMORY.md](assets/MEMORY.md) 和四个任务模板生成文件。按项目语言与目录映射替换占位符、修复相对链接，并补入实际可确认的事实。模板本身保留占位符，实际任务记录必须填真实值或明确的 `null` / `NOT_RUN`。

架构和 Memory 文件只做精简的事实与资料索引。已有 ADR 或决策记录继续由原文件拥有；不另造一套决策目录，也不把模板里的默认路径当成目标项目事实。

在现有 Agent 入口中增量加入共享规则和当前任务的读取方式。新文件夹可以创建简短入口，指向共享工作流。不要整文件覆盖已有指令，也不要复制来源项目的规则、历史测试结果、私有路径或旧阻塞项。

建立一个真实且范围可控的试点任务；本次工作流落地和文档完善本身可作为试点。按已有命名规则选唯一任务 ID；没有规则时使用描述性 slug。任务记录分别采用 [task.md](assets/task.md)、[plan.md](assets/plan.md)、[handoff.md](assets/handoff.md)、[log.md](assets/log.md) 的职责。

仅在需要项目后续路线时读取 [references/rollout.md](references/rollout.md)，把适用的 V1/V2 工作项放进项目已有计划。已有详细方案保留为权威来源并链接，不复制出两份计划。

## 3. 验证执行端入口

检查实际安装版本、帮助信息和可用的项目文档，确认执行端如何加载指令。不要预设 CLI 名称、会话恢复参数、Skill 目录或可用的模型路由。

如果执行端不自动加载所选入口，采用其真实支持的配置或显式读取提示词，并记录实际方式。文件存在只证明文件已创建，不能证明 Agent 已读取它。

真实 Agent 调用应处于用户已授权的试点范围，使用现有认证与明确的上下文范围。发生工具拒绝或自动审批拒绝时，不更换入口绕过；完成其余工作，说明具体拒绝动作和原因。只在仍缺少所需授权时请求确认，不把一次环境问题升级成所有项目都必须额外审批的规则。

## 4. 顺序执行双向试点

按 [references/validation.md](references/validation.md) 选择适用的验证步骤。A 写好 Checkpoint 并停止任务写入后，B 核对真实文件与 Git 状态并继续一个未完成事项；B 写回 Checkpoint 并停止后，A 再核对并接手。

一个工作区同一时刻只有一个任务写入者。用户手动切换与受监督的顺序调用均可；不能用另一个通用子 Agent 冒充用户要求的实际产品。只读核对可验证上下文接力，但必须单独说明编辑接力尚未验证。

记录每个方向的真实输入、动作、结果、下一步和接收方核对。若环境、认证、权限或产品能力阻止实测，标记 `BLOCKED` 或 `NOT_RUN`，保留精确人工步骤；不要把“文件已准备好”写成双向交接已通过。

测试代码时记录实际代码提交；包含未提交修改时另记工作区快照依据和检查时间。非 Git 场景用实际文件清单或相关文件摘要描述已验证内容。若项目规则禁止在文档存提交号，使用项目允许的稳定版本证据位置或报告冲突；不能把会移动的 `HEAD` 当作固定提交的替代证据。

## 5. 验收与报告

使用目标项目现有的相关文档或脚本检查，并检查新增文件的链接、占位符、换行、任务 ID 和状态一致性。空文件夹无现成门禁时完成这些文件检查，明确没有产品代码测试。

只更新本任务的记录，不为得到干净工作区而清理用户修改。提交、推送、跨设备同步和真实外部调用遵循现有用户授权与项目政策；报告实际保存状态。

最终报告新建和修改文件、采用的既有约定、执行过的检查、两个方向各自的试点结果、跨设备同步条件、剩余事项及 V1/V2 建议。两个方向未全部通过时，明确 V0 尚未完整验收。
